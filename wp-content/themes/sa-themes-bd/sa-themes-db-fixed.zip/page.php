<?php get_header(); ?>
<div class="main-block" id="main-content">
	<?php the_content(); ?>
</div>
<?php get_footer(); ?>