<?php get_header(); ?>
<div class="main-block operator-page">
	<?php the_content(); ?>
</div>
<?php get_footer(); ?>